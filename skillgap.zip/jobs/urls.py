from django.urls import path
from .views import skill_gap_view

urlpatterns = [
    path("", skill_gap_view, name="home"),
]