from django.shortcuts import render
from .utils import (
    extract_skills,
    get_skill_gap,
    get_recommendations,
    extract_text_from_pdf,
    calculate_score,
)
from .models import Job

# 🔥 CHART IMPORTS
import base64
from io import BytesIO
import matplotlib.pyplot as plt


# 🔥 CHART FUNCTION
def generate_chart(gap):
    skills = [skill for skill, _ in gap][:5]
    counts = [count for _, count in gap][:5]

    if not skills:
        return None

    plt.figure()
    plt.bar(skills, counts)

    buffer = BytesIO()
    plt.savefig(buffer, format="png")
    buffer.seek(0)

    image_png = buffer.getvalue()
    buffer.close()

    return base64.b64encode(image_png).decode("utf-8")


# 🔥 CLEAN ROADMAP (THIS IS THE FIX)
def build_roadmap(gap):
    roadmap = []

    for skill, demand in gap[:6]:
        roadmap.append({
            "skill": skill,
            "demand": min(demand, 100),  # fake % cap
            "course": f"Learn {skill} Complete Course",
            "link": f"https://www.youtube.com/results?search_query=learn+{skill}"
        })

    return roadmap


# 🔥 MAIN VIEW
def skill_gap_view(request):
    result = []
    score = None
    top_skills = []
    matched_skills = []
    chart = None
    roadmap = []

    # 👇 always show jobs
    jobs = Job.objects.all()[:10]

    if request.method == "POST":

        # 👇 resume
        if request.FILES.get("resume"):
            file = request.FILES["resume"]
            text = extract_text_from_pdf(file)
            user_skills_list = extract_skills(text)

        # 👇 manual input
        else:
            user_skills = request.POST.get("skills", "")
            user_skills_list = [
                s.strip().lower()
                for s in user_skills.split(",")
                if s.strip()
            ]

        all_jobs = Job.objects.all()

        # 🔥 GAP
        gap = get_skill_gap(user_skills_list, all_jobs)

        # 🔥 MATCHED SKILLS
        all_required_skills = {
            skill.name.lower()
            for job in all_jobs
            for skill in job.skills.all()
        }

        matched_skills = [
            skill for skill in user_skills_list
            if skill in all_required_skills
        ]

        # 🔥 SCORE
        score = calculate_score(user_skills_list, all_jobs)

        # 🔥 RECOMMENDATIONS
        result = get_recommendations(gap)

        # 🔥 TOP SKILLS (clean tuple)
        top_skills = gap[:3]

        # 🔥 CHART
        chart = generate_chart(gap)

        # 🔥 ROADMAP (FIXED)
        roadmap = build_roadmap(gap)

    return render(request, "skill_gap.html", {
        "jobs": jobs,
        "result": result,
        "score": score,
        "top_skills": top_skills,
        "matched_skills": matched_skills,
        "chart": chart,
        "roadmap": roadmap,
    })